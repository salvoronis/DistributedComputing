//
// Created by salvoroni on 1/5/22.
//

#ifndef PA1_LAMPORT_UTILS_H
#define PA1_LAMPORT_UTILS_H

void inc_lamport(void);

void set_lamport(timestamp_t val);

#endif //PA1_LAMPORT_UTILS_H
