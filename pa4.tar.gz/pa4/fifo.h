//
// Created by salvoroni on 1/6/22.
//

#ifndef PA1_FIFO_H
#define PA1_FIFO_H

void push(int pid);
int pop();
int is_empty();

#endif //PA1_FIFO_H
